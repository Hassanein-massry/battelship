#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>
#include<math.h>
#include<conio.h>
#include<time.h>
#include<windows.h>
int Size;
int moch=0;
int moch2=0;
int getsize(){
  int size;
  FILE *fp3=fopen("size.txt","r");
  fscanf(fp3,"%d",&size);
  fclose(fp3);
  return size;
}
struct playerr{
  char namee[20];
  int scoro;
};
struct  playerr player_list[100];
struct shisho{
  int score;
  int numberr_of_ships;
  int sizee_of_ships;

};
struct ships{
  int number_of_ships;
  int size_of_ships;
};
struct ships Schip[10];
struct cells {
  int score;
  int va1;
  int va2;
};
struct player {
	char board[100][100];
  struct cells Cell0[100][100];

};
struct player list[2];
void delay(int number_of_seconds)
{
    // Converting time into milli_seconds
    int milli_seconds = 500 * number_of_seconds;

    // Storing start time
    clock_t start_time = clock();

    // looping till required time is not achieved
    while (clock() < start_time + milli_seconds)
        ;
}
void nim_delay(int number_of_seconds)
{
    // Converting time into milli_seconds
    int milli_seconds = 150 * number_of_seconds;

    // Storing start time
    clock_t start_time = clock();

    // looping till required time is not achieved
    while (clock() < start_time + milli_seconds)
        ;
}
void nim2_delay(int number_of_seconds)
{
    // Converting time into milli_seconds
    int milli_seconds = 50 * number_of_seconds;

    // Storing start time
    clock_t start_time = clock();

    // looping till required time is not achieved
    while (clock() < start_time + milli_seconds)
        ;
}
void check_all(int turn, int count[5]){
  int flag =0;
count[0]=0;
for (int k = 1; k <=4 ; k++)
{
  count[k]=0;
  for (int i=0 ; i<Size ; i++)
    {
        for (int j = 0; j < Size; j++)
        {
        if(list[turn].Cell0[i][j].va1==k)
           {
               count[k]++;
           }
        }

    }
    //printf("count[%d] >> %d\n",k,count[k]);
}
}

void do_check_all(int turn , int count[5]){
  count[0]=0;
  for (int i = 1; i < 5; i++) {
    if(count[i]==0){
      for (int j = 0; j < Size; j++) {
        for (int k = 0; k < Size; k++) {
          if (list[turn].Cell0[j][k].va2==i) {
            list[turn].board[j][k]='C';
          }
        }
      }
    }
  }
}



void delay_sentence(char sentence[1000] )
{
  for (int i = 0; i < strlen(sentence); i++) {
    printf("%c",sentence[i] );
    nim2_delay(1);
  }
}
int barayeh_tartib=0;
void create_the_board();
void draw_to_file(char our[20],int turn);
void put_the_ships_automatically(int toto);
void make_the_game(char playerr1[20], char playerr2[20]);
void make_the_game_auto(char playerr3[20]);
void dorost_the_x(int io);
void draw1(int turn);
void drawV(int turn);
void puttheships(int toto);
void select_player(char playerrr[20]){
    printf("\n" );
    printf(" \t\t\t\t    >> choose user <<");
    printf("\n");
    nim_delay(1);
    printf("\t\t\t\t     _____________________________\n" );
    printf("\t\t\t\t     |1 >> CHOOSE AN AVAIBLE USER|\n");
    printf("\t\t\t\t     |---------------------------|\n" );
    nim_delay(1);
    printf("\t\t\t\t     |2 >> CREATE A NEW USER     |\n" );
    printf("\t\t\t\t     |---------------------------|\n" );
    nim_delay(1);
    printf("\n" );
    printf("\t\t\t\t     PLEASE ENTER YOUR CHOICE  >>  " );
    int newvouroudi;
    scanf("%d", &newvouroudi);
    if(newvouroudi==1){
      FILE *fp=fopen("users.txt","r");
      int num_of_user[100];
      char names[100][20];
      int i=0;
      printf("\n");
      printf("\t\t\t\tTHE LIST OF USERS >> \n");
      printf("\n" );
      int op;
      char oo[20];
      int ooo=0;
      while (!feof(fp)) {
        fscanf(fp,"%d %s",&op,oo);
        ooo++;
      }
      rewind(fp);
      while (i<ooo-1) {
      fscanf(fp,"%d %s",&num_of_user[i],names[i]);
      printf("\t\t\t\t%d %s\n",num_of_user[i],names[i] );
      nim2_delay(1);
      i++;
      }
      printf("\n" );
      printf("\t\t\t\tplease enter your the number of your username >>  " );
      //printf("\n" );
      int o;
      while (1) {
      scanf("%d",&o);
      if (o>i){
        printf("\t\t\t\tWrong users : please enter the right number of your username  >>  ");
      }else{
        break;
      }
    }
      printf("\n");
      for (size_t j = 0; j < i; j++) {
        if(o==num_of_user[j]){
          strcpy(playerrr,names[j]);
          char str[]="WELCOME TO BATTELSHIPS GAMES";
          printf("\t\t\t\t  " );
          delay_sentence(str);
          char str2[]=" >>> ";
          delay_sentence(str2);
          delay_sentence(names[j]);
          printf("\n" );

          break;
        }
      }
    }else if(newvouroudi ==2){
      char newuser[100];
      printf("\t\t\t\t     PLEASE ENTER YOUR USERNAME >> ");
      scanf("%s",newuser );
      strcpy(playerrr,newuser);
      FILE *fp2=fopen("users.txt","a+");
      int num_of_user111[100];
      char names111[100][100];
      int y=0;
      while (!feof(fp2)) {
        fscanf(fp2,"%d %s",&num_of_user111[y],names111[y]);
        y++;
      }
      fprintf(fp2, "%d %s\n",y , newuser );
      fclose(fp2);

}
}
void check_board(char the_player[20], int score){
  FILE *fp6=fopen("score.txt","a+");
  char the_name[20];
  int the_score;
  int i=0;
  int flag =0;
  int current=0;
  while (!feof(fp6)) {
    fscanf(fp6, "%s %d",the_name , &the_score);
  }
  fprintf(fp6, "%s %d\n",the_player , score );
  fclose(fp6);
}
void check_board2(){
  FILE *fp61=fopen("score.txt","a+");
FILE *fp7 = fopen("scores.txt","w");
char thename[20];
int thescore;
int Thescore;
int j=0;
int jj=0;


int sosoo=0;
while (!feof(fp61)) {
  fscanf(fp61,"%s %d", thename ,&thescore );
sosoo++;
}
//printf("soso >> %d\n",sosoo );
rewind(fp61);
int chusmo=0;
while (chusmo<sosoo-1) {
  fscanf(fp61,"%s %d", thename ,&thescore );
  //printf("%s %d \n",thename ,thescore );
  int flag=0;
  for (size_t k = 0; k < j; k++) {
    if(strcmp(thename, player_list[k].namee)==0){
    //  printf("ared\n");
      Thescore=thescore;
      jj=k;
      player_list[k].scoro+=thescore;
      //printf("%d %s score >> %d\n",k, thename,  player_list[k].scoro);

      flag=1;
    }
  }
  if(flag==0){
  //  printf("not ared\n" );
    strcpy(player_list[j].namee, thename);
    player_list[j].scoro=thescore;
    j++;
  }
chusmo++;
}
//player_list[jj].scoro=Thescore;
fclose(fp61);
barayeh_tartib=j;
for (size_t g = 0; g <j; g++) {

  fprintf(fp7, "%s %d \n",player_list[g].namee,  player_list[g].scoro );
}
fclose(fp7);
}

void tartib(){
FILE *pf8=fopen("scores.txt", "r+");
FILE *pf9=fopen("finalboardscore.txt","w");
int temp=0;
for (size_t g = 0; g <barayeh_tartib; g++) {
  for (size_t h = 0; h < barayeh_tartib; h++) {
    if (player_list[h].scoro<player_list[g].scoro) {
      temp=player_list[g].scoro;
      player_list[g].scoro=player_list[h].scoro;
      player_list[h].scoro=temp;
      char tempo[20];
      strcpy(tempo,player_list[g].namee);
      strcpy(player_list[g].namee,player_list[h].namee);
      strcpy(player_list[h].namee,tempo);
    }
  }
}
for (size_t t = 0; t <barayeh_tartib; t++) {
  fprintf(pf9, "%s %d \n",player_list[t].namee,  player_list[t].scoro );
}
fclose(pf8);
fclose(pf9);
}


void scoreboard(){
  FILE *fp10=fopen("finalboardscore.txt","r");

  int i=1;
  char nameee[20];
  int namescore;
  int j=0;
  while (!feof(fp10)) {
    fscanf(fp10, "%s %d",nameee ,&namescore );
    j++;
  }
  rewind(fp10);
  while (i<j) {
    fscanf(fp10, "%s %d",nameee ,&namescore );
    printf("\t\t\t\t  || %d NAME OF PLAYER >> %s || SCORE >> %d\n",i , nameee, namescore );
    printf("\n" );
    i++;
  }
  delay(4);
  char str[]="\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n";
    delay_sentence(str);
    fclose(fp10);
}


void menu(){
  printf("\t\t\t\t        ________________________\n" );
  printf("\t\t\t\t\t|1 >> Play With Friends|\n");
  printf("\t\t\t\t        |......................|\n");
  nim_delay(1);
  printf("\t\t\t\t\t|2 >> Play With Boot   |\n" );
  printf("\t\t\t\t        |......................|\n");
  nim_delay(1);
  printf("\t\t\t\t\t|3 >> Load Last Game   |\n" );
  printf("\t\t\t\t        |......................|\n");
  nim_delay(1);
  printf("\t\t\t\t\t|4 >> Settings         |\n" );
  printf("\t\t\t\t        |......................|\n");
  nim_delay(1);
  printf("\t\t\t\t\t|5 >> Score Board      |\n" );
  printf("\t\t\t\t        |......................|\n");
  nim_delay(1);
  printf("\t\t\t\t\t|6 >> PLAYBACK         |\n" );
  printf("\t\t\t\t        |......................|\n");
  nim_delay(1);
  printf("\t\t\t\t\t|7 >> Quit The Game    |\n" );
  printf("\t\t\t\t        |......................|\n");
  nim_delay(1);
  printf("\n\n" );
}

void playback() {
  FILE  *pf11=fopen("playback1.txt","r");
  int c ;
  while (!feof(pf11)) {
    c=fgetc(pf11);
    printf("%c",c );
    if (c=='>') {
      delay(3);
    }
  }
  fclose(pf11);
}

int main() {
  //SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),BACKGROUND_BLUE|BACKGROUND_GREEN| BACKGROUND_INTENSITY);
  Size=getsize();
  system("COLOR b4");

  create_the_board();

  for (int i=0 ; i<Size ; i++)
  {
        for (int j = 0; j < Size; j++)
      {
          list[0].Cell0[i][j].score=0;
          list[1].Cell0[i][j].score=0;
          list[0].Cell0[i][j].va1=0;
          list[1].Cell0[i][j].va1=0;
          list[0].Cell0[i][j].va2=0;
          list[1].Cell0[i][j].va2=0;
      }

  }

  /*  int i=0;
    while(i<5){
    char vouroudi[2];
    printf("please enter your choice  \n");
    scanf("%s", vouroudi);
    list[i%2].board[vouroudi[0] - 65][ vouroudi[1] - 49]='!';
    draw1(i%2);
    printf("\n\n");
    if(i%2==0)
        draw1(i%2+1);
    else{
      draw1(i%2-1);
    }
    i++;
}*/
printf("\n");
delay(1);
printf ("\t\t >>     XXXXX   XXXX  XXXXXX XXXXXX XX     XXXXXX  XXXXX XX  XX XX XXXX       <<\n");
//delay(1);
printf ("\t\t   >>   XX  XX XX  XX   XX     XX   XX     XX     XX     XX  XX XX XX  XX    <<  \n");
//delay(1);
printf ("\t\t     >> XXXXX  XX  XX   XX     XX   XX     XXXX    XXXX  XXXXXX XX XXXX    <<  \n");
//delay(1);
printf ("\t\t   >>   XX  XX XXXXXX   XX     XX   XX     XX         XX XX  XX XX XX        <<\n");
//delay(1);
printf ("\t\t >>     XXXXX  XX  XX   XX     XX   XXXXXX XXXXXX XXXXX  XX  XX XX XX          <<\n");
//delay(1);
printf("\n");

int vouroudi;
while(1) {
  menu();
  printf("\n");
  printf("\t\t\t\t      PLEASE ENTER YOUR CHOICE >>  ");
  scanf("%d",&vouroudi );
  if(vouroudi==1){
    printf("\n");
    char player1[20];
    char player2[20];
    char str33[]="THE FIRST PLAYER";
    printf("\t\t\t\t  " );
    delay_sentence(str33);
    printf("\n");
    select_player(player1);
    char ali[]="ali";
    char moh[]="moh";


    printf("\t\t\t\t  " );
    char str4[]="PLAYER 1  >>>  ";
    delay_sentence(str4);
    delay_sentence(player1);
    printf("\n");
    puttheships(0);
    printf("\n");
    char str3[]="THE SECOND PLAYER";
    printf("\t\t\t\t  " );
    select_player(player2);
    //check_board(player2 , 15);
    printf("\t\t\t\t  " );
    char str5[]="PLAYER 2  >>>  ";
    delay_sentence(str5);
    delay_sentence(player2);
    printf("\n");
    puttheships(1);
    make_the_game(player1,player2);
  }else if(vouroudi==2){
    char player3[20];
    char str34[]="THE FIRST PLAYER";
    printf("\t\t\t\t  " );
    delay_sentence(str34);
    printf("\n");
    select_player(player3);
    printf("\t\t\t\t  " );
    char str44[]="PLAYER 1  >>>  ";
    delay_sentence(str44);
    delay_sentence(player3);
    printf("\n");
    puttheships(0);
    printf("\n");
    char delay_lines[]="\n\n\n\n\n\n\n\n\n\n\n";
    delay_sentence(delay_lines);
    printf("\t\t\t\t ");
    char line1[]="THE SECOND PLAYER IS THE COMPUTER ^_^ \n\t\t\t\t  AND THE COMPUTER'S MAP WILL BE RANDOMLY >> \n\t\t\t\t  |_('_')_| \n";
    delay_sentence(line1);
    delay(2);

    put_the_ships_automatically(1);
    make_the_game_auto(player3);


  }else if (vouroudi==3){

  }else if (vouroudi==4){
    printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n" );
    printf("\t\t\t\t        _________________________\n" );
    printf("\t\t\t\t\t|1 >> CHANGE MAP'S SIZE |\n");
    printf("\t\t\t\t        |.......................|\n");
    nim_delay(1);
    printf("\t\t\t\t\t|2 >> CHANGE SHIP'S SIZE|\n" );
    printf("\t\t\t\t        |.......................|\n");
    nim_delay(1);
    printf("\t\t\t\t\t|3 >> CHANGE GAME'S THEM|\n" );
    printf("\t\t\t\t        |.......................|\n");
    nim_delay(1);
    char liness[]="\n\n\n\n\n\n\n\n";
    delay_sentence(liness);
    printf("\t\t\t\t  PLEASE ENTER YOUR CHOICE >>" );
    int choice3;
    int ll=0;

    while (1) {
      scanf("%d",&choice3 );

      if(choice3==1){
        printf("\t\t\t\t  PLEASE ENTER THE LENGHT OF MAP N*N  >> THE MIN LENGHT IS 3 AND THE MAX ONE IS 20 \n \t\t\t\t BE CUREFULL THE LENGHT THAT YOU WILL \n\t\t\t\t CHOOSE WILL BE THE DEFAULT ONE\n \t\t\t\t AND BE CUREFULL THAT YOU HAVE TO CHANGE THE SIZE\n\t\t\t\t OF SHIPS BECAUSE IT WILL BE GREATER THEN THE MAP\n\n");
        int lenght;
        while (1) {
          printf("\t\t\t\t >> PLEASE ENTER THE  NEW LENGHT >> " );
          scanf("%d",&lenght );
            printf("\n\n");
          if(lenght>2 && lenght<21){
            FILE *pf4=fopen("size.txt","w");
            fprintf(pf4, "%d\n",lenght );
            fclose(pf4);
            FILE *pf5 = fopen("size.txt","r");
            int sizsize;
            fscanf(pf5,"%d",&sizsize);
            Size=sizsize;
            printf("\t\t\t\t  THE LENGHT IS CHANGED SUCCESSFULLE\n");
            ll=1;
            break;
          }else{
            printf("\t\t\t\t  PLEASE ENTER A NUMBER BETWEEN 2 AND 21\n");
          }

        }

        break;
      }else if(choice3==2){
        break;
      }else if(choice3==3){
        printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n" );
        printf("\t\t\t\t        _________________ ________\n" );
        printf("\t\t\t\t\t|1 >> FIRST THEM >THEM1 |\n");
        printf("\t\t\t\t        |.......................|\n");
        nim_delay(1);
        printf("\t\t\t\t\t|2 >> SECOND THEM>THEM2|\n" );
        printf("\t\t\t\t        |.......................|\n");
        nim_delay(1);
        printf("\t\t\t\t\t|3 >> THIRD THEM >THEM3|\n" );
        printf("\t\t\t\t        |.......................|\n");
        nim_delay(1);
        printf("\t\t\t\t\t|3 >> FAURD THEM >THEM4|\n" );
        printf("\t\t\t\t        |.......................|\n");
        nim_delay(1);
        int mythem;
        while (1) {
          scanf("%d",&mythem );
          if(mythem==1){
            system("COLOR A5");
            break;
          }else if(mythem==2){
            system("COLOR B0");
            break;
          }else if(mythem==3){
            system("COLOR C0");
            break;
          }else if(mythem==4){
            system("COLOR D");

            break;
          }else{
            printf("\t\t\t\t  PLEASE ENTER A WRIGHT INPUT 1 , 2 , 3 , 4 \n");
          }
        }

        break;
      }else{
        printf("\t\t\t\t  WRONG INPUT >> ! PLEASE ENTER THE WRITE INPUT\n" );
      }
    }
      if(choice3==1){
        printf("\t\t\t\t YOU CHANGED THE LENGHT OF THE MAP .\n HOW HAVE TO ENTER ANOTHER TIME EO THE GAME FOR PLAYING WITH THE NEW MAP'S LENGHT\n" );
        break;
      }
  }else if (vouroudi==5){
    scoreboard();

  }else if(vouroudi==7){
    exit(-1);
  }
  else if(vouroudi==6){
    playback();
  }else{
    char c;
  }
}
}
void save_to_playback(char thefirst[20],char thesecond[20]){
draw_to_file(thefirst,0);
draw_to_file(thesecond,1);
}
void puttheships(int toto){
  Schip[0].number_of_ships=1;
  Schip[0].size_of_ships=2;
  Schip[1].number_of_ships=2;
  Schip[1].size_of_ships=1;
  Schip[2].number_of_ships=1;
  Schip[2].size_of_ships=3;
  printf("\n" );
  delay(2);
  printf("\t\t\t\t     __________________________________\n" );
  printf("\t\t\t\t     |1 >> PUT THE SHIPS AUTOMATICALLY|\n");
  printf("\t\t\t\t     |--------------------------------|\n" );
  nim_delay(1);
  printf("\t\t\t\t     |2 >> PUT THE SHIPS MANUALLY     |\n" );
  printf("\t\t\t\t     |--------------------------------|\n" );
  nim_delay(1);
  printf("\n");
  printf("\t\t\t\t      ");
  char please[]="PLEASE ENTER YOUR CHOICE >>  ";
  delay_sentence(please);

  int choice;
  while (1) {
    scanf("%d",&choice );
    if(choice==1 || choice==2){
      break;
    }else {
      printf("\n" );
      printf("\t\t\t\t YOU ENTERED A WRONG CHOICE PLEASE ENTER A WRIGHT ONE !!" );
      printf("\n");
    }
  }
if (choice==2){
  int bool;
    for (size_t p = 0; p < 3; p++) {
      printf("\n");
      printf("\t\t\t\t  YOU HAVE %d ships from the size 1*%d \n",Schip[p].number_of_ships , Schip[p].size_of_ships );
      printf("\n");
    }
    printf("\n" );
    draw1(toto);
    printf("\n" );
    int number_of_ship =0;
    for (size_t r = 0; r <= 2; r++) {
      for (size_t t = 0; t < Schip[r].number_of_ships; t++) {
      int SIZO=Schip[r].size_of_ships;
    //  printf("\t\t\t\t  YOU HAVE %d SHIPS WITH THE FOLLOWING SIZES >> \n", );

    int vouroudi3[3];
    char vouroudi4[3];
    int direction=0;
    printf("\n");
    printf("\t\t\t\t >> NOW YOU HAVE TO ENTER THE FIRST LOCATION AND THE FILNAL ONE OF \n\t\t\t\t  %d SHIPS FROM THE SIZE 1*%d \n",Schip[r].number_of_ships, Schip[r].size_of_ships );
    printf("\n");
    while (1) {
      printf("\n");
    printf("\t\t\t\t   ENTER THE >ROW< THE THE >COLUMN< OF THE BEGINNING LOCATION  >> ");
    scanf("%d %d", &vouroudi3[0] , &vouroudi3[1]);
    printf("\n" );
    printf("\t\t\t\t  ENTER THE >ROW< THE THE >COLUMN< OF THE FINAL LOCATION  >> ");
    scanf("%d %d",&vouroudi4[0] , &vouroudi4[1] );
    vouroudi3[0]-=1;
    vouroudi3[1]-=1;
    vouroudi4[0]-=1;
    vouroudi4[1]-=1;
      char the_char;
      if(vouroudi3[1]==vouroudi4[1]){
        while(1){
          int equals= abs(vouroudi3[0]-vouroudi4[0])+1;
          int ee =vouroudi3[0]-vouroudi4[0];

          if(ee>=0){
            bool=0;
          }else{
            bool='1';
          }
        //  printf("%d %d \n",ee,bool );
          printf("%i\n",equals );
        if(equals!=Schip[r].size_of_ships){
          printf("\t\t\t\t  !ERROR! >> PLEASE THE SIZE OF SHIP MUST BE EQUAL TO THE FOLLOWIN SIZE  >> %d\n",Schip[r].size_of_ships );
          printf("\n");
          printf("\t\t\t\t  THE INITIAL POSITION: row then column  >> \n");
          scanf("%d %d", &vouroudi3[0] , &vouroudi3[1]);
          printf("\n");
          printf("\t\t\t\t  THE FINAL POSITION : row then column >>\n");
          scanf("%d %d", &vouroudi4[0] , &vouroudi4[1]);
          vouroudi3[0]-=1;
          vouroudi3[1]-=1;
          vouroudi4[0]-=1;
          vouroudi4[1]-=1;
        }

      break;}
      direction=1;
      break;
      }else if(vouroudi3[0]==vouroudi4[0]){
        while(1){
          int equals= abs(vouroudi3[1]-vouroudi4[1])+1;
          int eee =vouroudi3[1]-vouroudi4[1];
          if(eee>=0){
            bool=0;
          }else{
            bool=1;
          }
          //printf("%d %d \n",eee,bool );



        if(equals!=Schip[r].size_of_ships){
          printf("\t\t\t\t  !ERROR! >> PLEASE THE SIZE OF SHIP MUST BE EQUAL TO THE FOLLOWIN SIZE  >> %d\n",Schip[r].size_of_ships );
          printf("\n");
          printf("\t\t\t\t  THE INITIAL POSITION :row then column >> \n");
          scanf("%d %d", &vouroudi3[0] , &vouroudi3[1]);
          printf("\n");
          printf("\t\t\t\t  THE FINAL POSITION : row then column >> \n");
          scanf("%d %d", &vouroudi4[0] , &vouroudi4[1]);
          vouroudi3[0]-=1;
          vouroudi3[1]-=1;
          vouroudi4[0]-=1;
          vouroudi4[1]-=1;
        }
      break;
    }
      direction=2;

      break;
      }else if(vouroudi3[0]!=vouroudi4[0] && vouroudi3[1]!=vouroudi4[1]){
        printf("\n");
        printf("\t\t\t\t  !ERROR! >> PLEASE REENTER THE WRIGHT POSITION \n");
      }

    }
    if(direction==1){
    int a , b;
    int flag1=0;
    number_of_ship++;
    int dd=0;


for (size_t l = 0; l < SIZO; l++) {

   if(list[toto].board[vouroudi3[0]-l ][ vouroudi3[1]]=='!'||list[toto].board[vouroudi3[0]-l][ vouroudi3[1]]=='x'){
    flag1=1;
    break;
  }
}
 if(flag1==1){
  printf("\n" );
  printf("\t\t\t\t  YOU CANNOT DO THAT .\n\t\t\t\t  WE MUST HAVE AT LEAST 1 LINE  BETWEEN ECH OF 2 SHIPS .\n" );
  printf("\n");
  t--;
  number_of_ship--;
}else{
//  printf("the cahr %d\n",bool );
 if(bool==0){
    for (size_t p = 0; p < SIZO; p++) {

      list[toto].board[vouroudi3[0]-p ][ vouroudi3[1]]='!';
      list[toto].Cell0[vouroudi3[0]-p ][ vouroudi3[1]].va1=number_of_ship;
      list[toto].Cell0[vouroudi3[0]-p ][ vouroudi3[1]].va2=number_of_ship;
      if(SIZO==1){
        list[toto].Cell0[vouroudi3[0]-p][ vouroudi3[1]].score=25;
      }
      if(SIZO==2){
        list[toto].Cell0[vouroudi3[0]-p ][ vouroudi3[1]].score=12;
      }
      if(SIZO==3){
        list[toto].Cell0[vouroudi3[0]-p][ vouroudi3[1]].score=8;
      }
      if(SIZO==5){
        list[toto].Cell0[vouroudi3[0]-p][ vouroudi3[1]].score=5;
      }

      if(list[toto].board[vouroudi3[0]-p -1][ vouroudi3[1]]!='!')
      list[toto].board[vouroudi3[0]-p -1][ vouroudi3[1]]='x';
      if(list[toto].board[vouroudi3[0]-p+1][vouroudi3[1]]!='!')
      list[toto].board[vouroudi3[0]-p+1][vouroudi3[1]]='x';
      if(list[toto].board[vouroudi3[0]-p -1][ vouroudi3[1]-1]!='!')
      list[toto].board[vouroudi3[0]-p -1][ vouroudi3[1] -1]='x';
      if(list[toto].board[vouroudi3[0]-p -1][ vouroudi3[1]+1]!='!')
      list[toto].board[vouroudi3[0]-p -1][ vouroudi3[1] +1]='x';
      if(list[toto].board[vouroudi3[0]-p+1][vouroudi3[1]-1]!='!')
      list[toto].board[vouroudi3[0]-p+1][vouroudi3[1]-1]='x';
      if(list[toto].board[vouroudi3[0]-p+1][vouroudi3[1]+1]!='!')
      list[toto].board[vouroudi3[0]-p+1][vouroudi3[1]+1]='x';
      if(list[toto].board[vouroudi3[0]-p+1][vouroudi3[1]+1]!='!');
      list[toto].board[vouroudi3[0]-p][vouroudi3[1]+1]='x';
      if(list[toto].board[vouroudi3[0]-p][vouroudi3[1]-1]!='!');
      list[toto].board[vouroudi3[0]-p][vouroudi3[1]-1]='x';
    }}else{
      vouroudi3[0]--;
      for (size_t p = SIZO; p > 0; p--) {


        list[toto].board[vouroudi3[0]+p ][ vouroudi3[1]]='!';
        list[toto].Cell0[vouroudi3[0]+p ][ vouroudi3[1]].va1=number_of_ship;
        list[toto].Cell0[vouroudi3[0]+p ][ vouroudi3[1]].va2=number_of_ship;
        if(SIZO==1){
          list[toto].Cell0[vouroudi3[0]+p][ vouroudi3[1]].score=25;
        }
        if(SIZO==2){
          list[toto].Cell0[vouroudi3[0]+p ][ vouroudi3[1]].score=12;
        }
        if(SIZO==3){
          list[toto].Cell0[vouroudi3[0]+p][ vouroudi3[1]].score=8;
        }
        if(SIZO==5){
          list[toto].Cell0[vouroudi3[0]+p][ vouroudi3[1]].score=5;
        }

        if(list[toto].board[vouroudi3[0]+p -1][ vouroudi3[1]]!='!')
        list[toto].board[vouroudi3[0]+p -1][ vouroudi3[1]]='x';
        if(list[toto].board[vouroudi3[0]+p+1][vouroudi3[1]]!='!')
        list[toto].board[vouroudi3[0]+p+1][vouroudi3[1]]='x';
        if(list[toto].board[vouroudi3[0]+p -1][ vouroudi3[1]-1]!='!')
        list[toto].board[vouroudi3[0]+p -1][ vouroudi3[1] -1]='x';
        if(list[toto].board[vouroudi3[0]+p -1][ vouroudi3[1]+1]!='!')
        list[toto].board[vouroudi3[0]+p -1][ vouroudi3[1] +1]='x';
        if(list[toto].board[vouroudi3[0]+p+1][vouroudi3[1]-1]!='!')
        list[toto].board[vouroudi3[0]+p+1][vouroudi3[1]-1]='x';
        if(list[toto].board[vouroudi3[0]+p+1][vouroudi3[1]+1]!='!')
        list[toto].board[vouroudi3[0]+p+1][vouroudi3[1]+1]='x';
        if(list[toto].board[vouroudi3[0]+p+1][vouroudi3[1]+1]!='!');
        list[toto].board[vouroudi3[0]+p][vouroudi3[1]+1]='x';
        if(list[toto].board[vouroudi3[0]+p][vouroudi3[1]-1]!='!');
        list[toto].board[vouroudi3[0]+p][vouroudi3[1]-1]='x';
      }
    }
  }
    draw1(toto);
}else if(direction==2){
  int a , b;
  int flag1=0;
  number_of_ship++;
  int dd=0;

for (size_t l = 0; l < SIZO; l++) {
if(list[toto].board[vouroudi3[0]][ vouroudi3[1]+l ]=='!'||list[toto].board[vouroudi3[0]][ vouroudi3[1]-l ]=='x'){
  flag1=1;
  break;
}
}
if(flag1==1){
printf("\n" );
printf("\t\t\t\t  YOU CANNOT DO THAT .\n\t\t\t\t  WE MUST HAVE AT LEAST 1 LINE  BETWEEN ECH OF 2 SHIPS .\n" );
printf("\n");
t--;
number_of_ship--;
}else{
  if(bool!=0){
  for (size_t p = 0; p < SIZO; p++) {
    list[toto].board[vouroudi3[0] ][ vouroudi3[1]+p]='!';
    list[toto].Cell0[vouroudi3[0] ][ vouroudi3[1]+p].va1=number_of_ship;
    list[toto].Cell0[vouroudi3[0] ][ vouroudi3[1]+p ].va2=number_of_ship;
    if(SIZO==1){
      list[toto].Cell0[vouroudi3[0] ][ vouroudi3[1]+p ].score=25;
    }
    if(SIZO==2){
      list[toto].Cell0[vouroudi3[0] ][vouroudi3[1]+p].score=12;
    }
    if(SIZO==3){
      list[toto].Cell0[vouroudi3[0]][vouroudi3[1]+p ].score=8;
    }
    if(SIZO==5){
      list[toto].Cell0[vouroudi3[0] ][vouroudi3[1]+p].score=5;
    }
    if(list[toto].board[vouroudi3[0]-1][ vouroudi3[1]+p ]!='!')
    list[toto].board[vouroudi3[0]-1][ vouroudi3[1]+p ]='x';
    if(list[toto].board[vouroudi3[0]+1][vouroudi3[1]+p]!='!')
    list[toto].board[vouroudi3[0]+1][vouroudi3[1]+p]='x';
    if(list[toto].board[vouroudi3[0]-1][ vouroudi3[1]+p -1]!='!')
    list[toto].board[vouroudi3[0]-1][ vouroudi3[1] +p-1]='x';
    if(list[toto].board[vouroudi3[0]-1][ vouroudi3[1]+p +1]!='!')
    list[toto].board[vouroudi3[0]-1][ vouroudi3[1] +p+1]='x';
    if(list[toto].board[vouroudi3[0]+1][vouroudi3[1]+p-1]!='!')
    list[toto].board[vouroudi3[0]+1][vouroudi3[1]+p-1]='x';
    if(list[toto].board[vouroudi3[0]+1][vouroudi3[1]+p+1]!='!')
    list[toto].board[vouroudi3[0]+1][vouroudi3[1]+p+1]='x';
    if(list[toto].board[vouroudi3[0]+1][vouroudi3[1]+p+1]!='!');
    list[toto].board[vouroudi3[0]+1][vouroudi3[1]+p+1]='x';
  // if(list[0].board[vouroudi3[0]+dd-65][vouroudi3[1]+p-49-1]!='!');
    //list[0].board[vouroudi3[0]+dd-65][vouroudi3[1]+p-49-1]='x';
  }}else{
    vouroudi3[1]++;
    for (size_t p = SIZO; p >0; p--) {
      list[toto].board[vouroudi3[0] ][ vouroudi3[1]-p]='!';
      list[toto].Cell0[vouroudi3[0] ][ vouroudi3[1]-p].va1=number_of_ship;
      list[toto].Cell0[vouroudi3[0] ][ vouroudi3[1]-p ].va2=number_of_ship;
      if(SIZO==1){
        list[toto].Cell0[vouroudi3[0] ][ vouroudi3[1]-p ].score=25;
      }
      if(SIZO==2){
        list[toto].Cell0[vouroudi3[0] ][vouroudi3[1]-p].score=12;
      }
      if(SIZO==3){
        list[toto].Cell0[vouroudi3[0]][vouroudi3[1]-p ].score=8;
      }
      if(SIZO==5){
        list[toto].Cell0[vouroudi3[0] ][vouroudi3[1]-p].score=5;
      }
      if(list[toto].board[vouroudi3[0]-1][ vouroudi3[1]-p ]!='!')
      list[toto].board[vouroudi3[0]-1][ vouroudi3[1]-p ]='x';
      if(list[toto].board[vouroudi3[0]+1][vouroudi3[1]-p]!='!')
      list[toto].board[vouroudi3[0]+1][vouroudi3[1]-p]='x';
      if(list[toto].board[vouroudi3[0]-1][ vouroudi3[1]-p -1]!='!')
      list[toto].board[vouroudi3[0]-1][ vouroudi3[1] -p-1]='x';
      if(list[toto].board[vouroudi3[0]-1][ vouroudi3[1]-p +1]!='!')
      list[toto].board[vouroudi3[0]-1][ vouroudi3[1] -p+1]='x';
      if(list[toto].board[vouroudi3[0]+1][vouroudi3[1]-p-1]!='!')
      list[toto].board[vouroudi3[0]+1][vouroudi3[1]-p-1]='x';
      if(list[toto].board[vouroudi3[0]+1][vouroudi3[1]-p+1]!='!')
      list[toto].board[vouroudi3[0]+1][vouroudi3[1]-p+1]='x';
      if(list[toto].board[vouroudi3[0]+1][vouroudi3[1]-p+1]!='!')
      list[toto].board[vouroudi3[0]+1][vouroudi3[1]-p+1]='x';
      if(list[toto].board[vouroudi3[0]][vouroudi3[1]-p+1]!='!')
      list[toto].board[vouroudi3[0]][vouroudi3[1]-p+1]='x';}

  }
}
  draw1(toto);


}
}
}
}else if(choice==1){
  printf("\t\t\t\t  ");
  char you[]=" >> YOU CHOOSE THE RANDOM SHIPS MODE << \n\t\t\t\t        >>AND YOUR MAP WILL BE << \n\n\t\t\t\t                ^_^ \n\n ";
  delay_sentence(you);
  delay(1);
  int number_of_ship1=0;
  for (size_t r = 0; r <= 2; r++) {
    for (size_t t = 0; t < Schip[r].number_of_ships; t++) {
       int SIZO=Schip[r].size_of_ships;
       int a=(rand() % (Size-1 - 2 + 1)) + 2;
       int b=(rand() % (Size-1 - 2 + 1)) + 2;
       //printf(" >> %d >> %d \n",a,b );
       int flag1=0;
       number_of_ship1++;
       for (size_t l = 0; l < SIZO; l++) {
       if(list[toto].board[a-l][b]=='!'||list[toto].board[a-l][b]=='x'){
         flag1=1;
         break;
       }
       }
       if(flag1==1){
       t--;
       number_of_ship1--;

       }else{
       for (size_t p = 0; p <SIZO ; p++) {
         list[toto].board[a-p ][b]='!';
         list[toto].Cell0[a-p][ b].va1=number_of_ship1;
         list[toto].Cell0[a-p][ b].va2=number_of_ship1;

         if(SIZO==1){
           list[toto].Cell0[a-p][ b].score=25;
         }
         if(SIZO==2){
           list[toto].Cell0[a-p][b].score=12;
         }
         if(SIZO==3){
           list[toto].Cell0[a-p][b].score=8;
         }
         if(SIZO==5){
           list[toto].Cell0[a-p][b].score=5;
         }
         if(list[toto].board[a-p -1][b]!='!')
         list[toto].board[a-p -1][ b]='x';
         if(list[toto].board[a-p+1][b]!='!')
         list[toto].board[a-p+1][b]='x';
         if(list[toto].board[a-p -1][b-1]!='!')
         list[toto].board[a-p -1][b-1]='x';
         if(list[toto].board[a-p -1][b+1]!='!')
         list[toto].board[a-p -1][b+1]='x';
         if(list[toto].board[a-p+1][b-1]!='!')
         list[toto].board[a-p+1][b-1]='x';
         if(list[toto].board[a-p+1][b+1]!='!')
         list[toto].board[a-p+1][b+1]='x';
         if(list[toto].board[a-p+1][b+1]!='!');
         list[toto].board[a-p][b+1]='x';
         if(list[toto].board[a-p][b-1]!='!');
         list[toto].board[a-p][b-1]='x';
       }}
  }
}
draw1(toto);
delay(2);
  }

}

void create_the_board()
{
  for (int i = 0; i < Size; i++)
    for (int j = 0; j < Size; j++)
        {list[0].board[i][j] = 'W';
        list[1].board[i][j]='W';}

}
void draw1(int turn)
{
  //SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),BACKGROUND_RED|BACKGROUND_GREEN);

    printf("\t\t\t\t     ");
    for (int i = 0; i < Size; i++)
    {
      if(i<9)
          printf(" %i ", i + 1);
       else if(i>=9)
          printf("%i ", i + 1);
    }
    printf("\n");

    // board display
    for (int i = 0; i < Size; i++)
    {    printf("\t\t\t\t  ");

        // column names display
        if(i<9)
            printf(" %i ", i + 1);
         else if (i>=9)
            printf("%i ", i + 1);
        for (int j = 0; j < Size; j++)
        {  //SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),BACKGROUND_RED|BACKGROUND_GREEN);
          //system("COLOR B5");
            printf(" %c ", list[turn].board[i][j]);
        }

        printf("\n");
    }
    nim_delay(1);

    //SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),BACKGROUND_BLUE|BACKGROUND_GREEN| BACKGROUND_INTENSITY);
}
void drawU(int turn)
{
  //SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),BACKGROUND_RED|BACKGROUND_GREEN);

    printf("\t\t\t\t     ");
    for (int i = 0; i < Size; i++)
    {if(i<9)
        printf(" %i ", i + 1);
     else if(i>=9)
        printf("%i ", i + 1);
    }
    printf("\n");

    // board display
    for (int i = 0; i < Size; i++)
    { printf("\t\t\t\t  ");
        // column names display
        if(i<9)
            printf(" %i ", i + 1);
         else if (i>=9)
            printf("%i ", i + 1);
        for (int j = 0; j < Size; j++)
        {if(list[turn].board[i][j]=='!'||list[turn].board[i][j]=='x'||list[turn].board[i][j]=='W'){
          printf(" ? ");
        }else{
            printf(" %c ", list[turn].board[i][j]);}
        }
        printf("\n");
    }
    nim_delay(1);
//    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),BACKGROUND_BLUE|BACKGROUND_GREEN| BACKGROUND_INTENSITY);
}

void draw_to_file(char our[20],int turn) {
  FILE *fp10=fopen("playback1.txt","a+");
fprintf(fp10, " THE MAP OF  %s\n",our);
      fprintf(fp10,"\t\t\t\t     ");
      for (int i = 0; i < Size; i++)
      {
        if(i<9)
            fprintf(fp10," %i ", i + 1);
         else if(i>=9)
            fprintf(fp10,"%i ", i + 1);
      }
      fprintf(fp10,"\n");

      // board display
      for (int i = 0; i < Size; i++)
      {    fprintf(fp10,"\t\t\t\t  ");

          // column names display
          if(i<9)
              fprintf(fp10," %i ", i + 1);
           else if (i>=9)
              fprintf(fp10,"%i ", i + 1);
          for (int j = 0; j < Size; j++)
          {  //SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),BACKGROUND_RED|BACKGROUND_GREEN);
            //system("COLOR B5");
              fprintf(fp10," %c ", list[turn].board[i][j]);
          }

         fprintf(fp10,"\n");
      }
    //  nim_delay(1);
    fprintf(fp10, ">\n");
    fprintf(fp10,"\n\n\n");
      fclose(fp10);
}


void dorost_the_x(int io){
  for (int i = 0; i < Size; i++)
  {
      for (int j = 0; j < Size; j++)
      {
        if(list[io].board[i][j]=='x')
        {
        list[io].board[i][j]='W';
      }
    }
  }
}
void make_the_game_auto(char playerr3[20]){
  FILE *fpp=fopen("playback1.txt","w");
  fclose(fpp);
  dorost_the_x(0);
  dorost_the_x(1);
  printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
  printf("-------------------------------------------------------------------------------------------------------------------------\n");
  printf("\t\t\t\t\t      THE GAME IS STARTING\n" );
  printf("-------------------------------------------------------------------------------------------------------------------------\n" );
char str12 []="\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n";
char str13 []="\n\n\n\n\n\n\n\n\n";
char str14 []="\n\n\n\n";
delay_sentence(str12);
delay(2);
delay_sentence(str12);
  int vouroudi5[3];
  int vouroudi6[3];
  int Totalscore1=0;
  int Totalscore2=0;
  int count11[5];
  int count22[5];
  int count1=0,count2=0;
  while (count1<7 && count2<7) {
    printf("\n");
    delay_sentence(str13);
    printf("\t\t\t\t  THE TURN OF THE PLAYER >>  %s\n",playerr3 );
    delay_sentence(str14);
    drawU(1);
    delay_sentence(str14);
    printf("\t\t\t\t  PLEASE ENTER THE BLOCK THAT YOU WANT TO EXPLOSE :row then column of the location >>>  ");
  scanf("%d %d",&vouroudi5[0] , &vouroudi5[1] );
  vouroudi5[0]-=1;
  vouroudi5[1]-=1;

  list[1].Cell0[vouroudi5[0]][vouroudi5[1]].va1=0;
  if(list[1].board[vouroudi5[0]][vouroudi5[1]]=='!'){
    list[1].board[vouroudi5[0]][vouroudi5[1]]='E';
    count1++;
  }
  if(list[1].board[vouroudi5[0]][vouroudi5[1]]=='W'){
    list[1].board[vouroudi5[0]][vouroudi5[1]]='#';
  }
  if(list[1].board[vouroudi5[0]][vouroudi5[1]]=='x'){
    list[1].board[vouroudi5[0]][vouroudi5[1]]='#';
  }
  check_all(1,count22);
  do_check_all(1,count22);
printf("YOUR MAP >> \n");
  draw1(0);
  printf("\n");
  delay(1);
  printf("YOUR ENNEMIE'S MAP >> \n");
  Totalscore1+=list[1].Cell0[vouroudi5[0]][vouroudi5[1]].score;
  drawU(1);
  delay_sentence(str14);
  delay(2);
  delay_sentence(str13);
  delay_sentence(str13);
  printf("\t\t\t\t  SCORES :: %s >>  %d    ||    COMPUTER >>  %d\n",playerr3 , Totalscore1  , Totalscore2 );
  delay_sentence(str12);
  delay(4);
  printf("\t\t\t\t  THE TURN OF THE COMPUTER  >>  \n");
  delay_sentence(str13);
  drawU(0);
  delay_sentence(str14);
  int c=rand()%10;
  int d=rand()%10;
    list[0].Cell0[c][d].va1=0;
  if(list[0].board[c][d]=='!'){
    list[0].board[c][d]='E';
    count2++;

  }
  if(list[0].board[c][d]=='W'){
    list[0].board[c][d]='#';
  }

  check_all(0,count11);
  do_check_all(0,count11);
printf("THE COMPUTER'S MAP >> \n");
Totalscore2+=list[0].Cell0[c][d].score;
  draw1(1);
  printf("\n");
  delay(1);
printf("THE PLAYER'S MAP>>\n");
delay(1);
printf("\n");
  drawU(0);
  printf("\n\n\n\n\n\n\n\n\n\n\n\n\n");
  printf("\t\t\t\t  SCORES :: %s >>  %d    ||    COMPUTER >>  %d",playerr3 , Totalscore1  , Totalscore2 );
  char sto[]="COMPUTER ^_^";
  save_to_playback(playerr3,sto);
  printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
  delay(4);

}
}

void make_the_game(char playerr1[20], char playerr2[20]){
  FILE *fpp=fopen("playback1.txt","w");
  fclose(fpp);
  dorost_the_x(0);
  dorost_the_x(1);
  printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
  printf("-------------------------------------------------------------------------------------------------------------------------\n");
  printf("\t\t\t\t\t      THE GAME IS STARTING\n" );
  printf("-------------------------------------------------------------------------------------------------------------------------\n" );
char str12 []="\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n";
char str13 []="\n\n\n\n\n\n\n\n\n";
char str14 []="\n\n\n\n";



delay_sentence(str12);
delay(2);
delay_sentence(str12);
  int vouroudi5[3];
  int vouroudi6[3];
  int Totalscore1=0;
  int Totalscore2=0;
  int imtyaz1=0;
  int imtyaz2=0;
  int count11[5];
  int count22[5];
  int count1=0,count2=0;
  while (count1<7 && count2<7) {
    printf("\n");
    delay_sentence(str13);
    printf("\t\t\t\t  THE TURN OF THE PLAYER >>  %s\n",playerr1 );
    delay_sentence(str14);
    drawU(1);
    delay_sentence(str14);
    printf("\t\t\t\t  PLEASE ENTER THE BLOCK THAT YOU WANT TO EXPLOSE :row then column of the location>>>  ");
  scanf("%d %d",&vouroudi5[0], &vouroudi5[1] );
  vouroudi5[0]-=1;
  vouroudi5[1]-=1;
  check_board(playerr1,list[1].Cell0[vouroudi5[0]][vouroudi5[1]].score);
  list[1].Cell0[vouroudi5[0]][vouroudi5[1]].va1=0;
  if(list[1].board[vouroudi5[0]][vouroudi5[1]]=='!'){
    list[1].board[vouroudi5[0]][vouroudi5[1]]='E';
    count1++;
  }
  if(list[1].board[vouroudi5[0]][vouroudi5[1]]=='W'){
    list[1].board[vouroudi5[0]][vouroudi5[1]]='#';
  }
  if(list[1].board[vouroudi5[0]][vouroudi5[1]]=='x'){
    list[1].board[vouroudi5[0]][vouroudi5[1]]='#';
  }
  check_all(1,count22);
  do_check_all(1,count22);
printf("YOUR MAP >> \n");
  draw1(0);
  printf("\n");
  delay(1);
  printf("YOUR ENNEMIE'S MAP >> \n");
  Totalscore1+=list[1].Cell0[vouroudi5[0]][vouroudi5[1]].score;
  imtyaz1+=list[1].Cell0[vouroudi5[0]][vouroudi5[1]].score;
  if(Totalscore1>100 && moch==0){
    char sttr[]="\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n";
    delay_sentence(sttr);
    printf("\t\t\t\t  " );
    char sttr2[]="GOOD JOB >> ";
    delay_sentence(sttr2);
    delay_sentence(playerr1);

    char sttr3[]="\t\t\t\t  NO YOU CAN USE THE MOCHAKK IF YOU WANT TO >ENTER y AND ELSE ENTER n ";
    printf("\n");
    char yesorno;
    scanf("%c",&yesorno );
    if(yesorno=='n'){
      printf("YOU CAN USE IT ANYWAY\n");
    }else if(yesorno=='y'){
      printf("\n" );
      printf("\t\t\t\t  DID YOU WANT TO EXPLOSE \n\t\t\t\t  1>>VERTICALLY \n\t\t\t\t 2>>HORIZONTALLY\n" );
      int horv;
      scanf("%d",&horv );
      while (1) {
      if(horv==1){
        printf("\t\t\t\t  PLEASE ENTER THE NUMBER OF ROW\n" );
        int row;
        while (1) {
        scanf("%d",&row );
        if(row>Size || row<0){
          printf("\t\t\t\t  WRONG ANSWER PLEASE REETER THE ROW >> ");
        }else{
          for (size_t i = 0; i < Size; i++) {

            if(list[1].board[row][i]=='!'){
              list[1].board[row][i]='E';
              check_board(playerr1,list[1].Cell0[row][i].score);
              list[1].Cell0[row][i].va1=0;
              count1++;
            }
            if(list[1].board[row][i]=='W'){
              check_board(playerr1,list[1].Cell0[row][i].score);
              list[1].Cell0[row][i].va1=0;
              list[1].board[row][i]='#';
            }
            if(list[1].board[row][i]=='x'){
              check_board(playerr1,list[1].Cell0[row][i].score);
              list[1].Cell0[row][i].va1=0;
              list[1].board[row][i]='#';
            }
          }
        }
}
        break;
      }else if(horv==2){

        printf("\t\t\t\t  PLEASE ENTER THE NUMBER OF COLUMN\n" );
        int column;
        while (1) {
        scanf("%d",&column );
        if(column>Size || column<0){
          printf("\t\t\t\t  WRONG ANSWER PLEASE REETER THE COLUMN >> ");
        }else{
          for (size_t i = 0; i < Size; i++) {

            if(list[1].board[i][column]=='!'){
              list[1].board[i][column]='E';
              check_board(playerr1,list[1].Cell0[i][column].score);
              list[1].Cell0[i][column].va1=0;
              count1++;
            }
            if(list[1].board[i][column]=='W'){
              check_board(playerr1,list[1].Cell0[i][column].score);
              list[1].Cell0[i][column].va1=0;
              list[1].board[i][column]='#';
            }
            if(list[1].board[i][column]=='x'){
              check_board(playerr1,list[1].Cell0[i][column].score);
              list[1].Cell0[i][column].va1=0;
              list[1].board[i][column]='#';
            }
          }
        }
}


        break;
      }else{
        printf("\t\t\t\t  WRONG ANSWER REENTER YOU CHOICE PLEASE\n");
      }}
    moch++;
    imtyaz1-=100;
  }}
  drawU(1);
  delay_sentence(str14);
  delay(2);
  delay_sentence(str13);
  delay_sentence(str13);
  printf("\t\t\t\t  SCORES :: %s >>  %d    ||    %s >>  %d\n",playerr1 , Totalscore1 , playerr2 , Totalscore2 );
  delay_sentence(str12);
  delay(4);
  printf("\t\t\t\t  THE TURN OF THE PLAYER >>  %s\n",playerr2 );
  delay_sentence(str13);
  drawU(0);
  delay_sentence(str14);
  printf("\t\t\t\t  PLEASE ENTER THE BLOCK THAT YOU WANT TO EXPLOSE row then column of the location >>>  ");
  scanf("%d %d ",&vouroudi6[0], &vouroudi6[1]);
  vouroudi6[0]-=1;
  vouroudi6[1]-=1;

  check_board(playerr2,list[0].Cell0[vouroudi6[0]][vouroudi6[1]].score);
    list[0].Cell0[vouroudi6[0]][vouroudi6[1]].va1=0;
  if(list[0].board[vouroudi6[0]][vouroudi6[1]]=='!'){
    list[0].board[vouroudi6[0]][vouroudi6[1]]='E';
    count2++;

  }
  if(list[0].board[vouroudi6[0]][vouroudi6[1]]=='W'){
    list[0].board[vouroudi6[0]][vouroudi6[1]]='#';
  }

  check_all(0,count11);
  do_check_all(0,count11);
printf("YOUR MAP >> \n");
Totalscore2+=list[0].Cell0[vouroudi6[0]][vouroudi6[1]].score;
imtyaz2+=list[0].Cell0[vouroudi6[0]][vouroudi6[1]].score;
  draw1(1);
  printf("\n");
  delay(1);
printf("YOUR ENNEMIE'S MAP>>\n");
delay(1);
printf("\n");
  drawU(0);
  if(Totalscore2>100 && moch2==0){
    char sttr[]="\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n";
    delay_sentence(sttr);
    printf("\t\t\t\t  " );
    char sttr2[]="GOOD JOB >> ";
    delay_sentence(sttr2);
    delay_sentence(playerr2);

    char sttr3[]="\t\t\t\t  NO YOU CAN USE THE MOCHAKK IF YOU WANT TO >ENTER y AND ELSE ENTER n ";
    printf("\n");
    char yesorno;
    scanf("%c",&yesorno );
    if(yesorno=='n'){
      printf("YOU CAN USE IT ANYWAY\n");
    }else if(yesorno=='y'){
      printf("\n" );
      printf("\t\t\t\t  DID YOU WANT TO EXPLOSE \n\t\t\t\t  1>>VERTICALLY \n\t\t\t\t 2>>HORIZONTALLY\n" );
      int horv;
      scanf("%d",&horv );
      while (1) {
      if(horv==1){
        printf("\t\t\t\t  PLEASE ENTER THE NUMBER OF ROW\n" );
        int row;
        while (1) {
        scanf("%d",&row );
        if(row>Size || row<0){
          printf("\t\t\t\t  WRONG ANSWER PLEASE REETER THE ROW >> ");
        }else{
          for (size_t i = 0; i < Size; i++) {

            if(list[0].board[row][i]=='!'){
              list[0].board[row][i]='E';
              check_board(playerr1,list[1].Cell0[row][i].score);
              list[0].Cell0[row][i].va1=0;
              count1++;
            }
            if(list[0].board[row][i]=='W'){
              check_board(playerr1,list[1].Cell0[row][i].score);
              list[0].Cell0[row][i].va1=0;
              list[0].board[row][i]='#';
            }
            if(list[0].board[row][i]=='x'){
              check_board(playerr1,list[1].Cell0[row][i].score);
              list[0].Cell0[row][i].va1=0;
              list[0].board[row][i]='#';
            }
          }
        }
}
        break;
      }else if(horv==2){
        int column;
        printf("\t\t\t\t  PLEASE ENTER THE NUMBER OF COLUMN\n" );
        int row;
        while (1) {
        scanf("%d",&column );
        if(column>Size || column<0){
          printf("\t\t\t\t  WRONG ANSWER PLEASE REETER THE COLUMN >> ");
        }else{
          for (size_t i = 0; i < Size; i++) {

            if(list[0].board[i][column]=='!'){
              list[0].board[i][column]='E';
              check_board(playerr1,list[1].Cell0[i][column].score);
              list[0].Cell0[i][column].va1=0;
              count1++;
            }
            if(list[0].board[i][column]=='W'){
              check_board(playerr1,list[1].Cell0[i][column].score);
              list[0].Cell0[i][column].va1=0;
              list[0].board[i][column]='#';
            }
            if(list[0].board[i][column]=='x'){
              check_board(playerr1,list[1].Cell0[i][column].score);
              list[0].Cell0[i][column].va1=0;
              list[0].board[i][column]='#';
            }
          }
        }
} break;
      }else{
        printf("\t\t\t\t  WRONG ANSWER REENTER YOU CHOICE PLEASE\n");
      }}
    moch2++;
    imtyaz2-=100;
  }
  }
  printf("\n\n\n\n\n\n\n\n\n\n\n\n\n");
  printf("\t\t\t\t  SCORES :: %s >>  %d    ||    %s >>  %d",playerr1 , Totalscore1 , playerr2 , Totalscore2 );
  printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
  delay(4);
check_board2();
tartib();
save_to_playback(playerr1,playerr2);

}

if(count1>count2){
  printf("\t\t\t\t  WINNER >> %s\n",playerr1 );
}else{
  printf("\t\t\t\t  WINNER >> %s\n",playerr2 );

}
}
void put_the_ships_automatically(int toto) {
  printf("\n" );
  int number_of_ship1=0;
  for (size_t r = 0; r <= 2; r++) {
    for (size_t t = 0; t < Schip[r].number_of_ships; t++) {
       int SIZO=Schip[r].size_of_ships;
       int a=(rand() % (Size-1 - 2 + 1)) + 2;
       int b=(rand() % (Size-1 - 2 + 1)) + 2;
       //printf(" >> %d >> %d \n",a,b );
       int flag1=0;
       number_of_ship1++;
       for (size_t l = 0; l < SIZO; l++) {
       if(list[toto].board[a-l][b]=='!'||list[toto].board[a-l][b]=='x'){
         flag1=1;
         break;
       }
       }
       if(flag1==1){
       t--;
       number_of_ship1--;

       }else{
       for (size_t p = 0; p <SIZO ; p++) {
         list[toto].board[a-p ][b]='!';
         list[toto].Cell0[a-p][ b].va1=number_of_ship1;
         list[toto].Cell0[a-p][ b].va2=number_of_ship1;

         if(SIZO==1){
           list[toto].Cell0[a-p][ b].score=25;
         }
         if(SIZO==2){
           list[toto].Cell0[a-p][b].score=12;
         }
         if(SIZO==3){
           list[toto].Cell0[a-p][b].score=8;
         }
         if(SIZO==5){
           list[toto].Cell0[a-p][b].score=5;
         }
         if(list[toto].board[a-p -1][b]!='!')
         list[toto].board[a-p -1][ b]='x';
         if(list[toto].board[a-p+1][b]!='!')
         list[toto].board[a-p+1][b]='x';
         if(list[toto].board[a-p -1][b-1]!='!')
         list[toto].board[a-p -1][b-1]='x';
         if(list[toto].board[a-p -1][b+1]!='!')
         list[toto].board[a-p -1][b+1]='x';
         if(list[toto].board[a-p+1][b-1]!='!')
         list[toto].board[a-p+1][b-1]='x';
         if(list[toto].board[a-p+1][b+1]!='!')
         list[toto].board[a-p+1][b+1]='x';
         if(list[toto].board[a-p+1][b+1]!='!');
         list[toto].board[a-p][b+1]='x';
         if(list[toto].board[a-p][b-1]!='!');
         list[toto].board[a-p][b-1]='x';
       }}
  }
}
draw1(toto);
}
